package com.crystal.Controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public interface StorageInterface {

	@RequestMapping (value = "/storage/volumes/updclients", method = RequestMethod.POST)
	public ReplyCientListDto updClients(@RequestBody StorageVolumeUpdClientsDto updClientData);
	
	//To Be Deleted	
	@RequestMapping (value = "/storage/volumes/replyclients", method = RequestMethod.POST)
	public ReplyCientListDto1 replyClients(@RequestBody StorageVolumeUpdClientsDto updClientData);

	//To Be Deleted
	@RequestMapping (value = "/ping", method = RequestMethod.GET)
	public String ping();
}
