package com.crystal.Entity;

import java.util.List;

public class Volume {

	private String volCluster;
	private String volId;
    private String volName;
    private String volPolicy;
    private List<String> volClientLst = null;
    
	public String getVolCluster() {
		return volCluster;
	}
	public void setVolCluster(String volCluster) {
		this.volCluster = volCluster;
	}
	public String getVolId() {
		return volId;
	}
	public void setVolId(String volId) {
		this.volId = volId;
	}
	public String getVolName() {
		return volName;
	}
	public void setVolName(String volName) {
		this.volName = volName;
	}
	public String getVolPolicy() {
		return volPolicy;
	}
	public void setVolPolicy(String volPolicy) {
		this.volPolicy = volPolicy;
	}
	public List<String> getVolClientLst() {
		return volClientLst;
	}
	public void setVolClientLst(List<String> volClientLst) {
		this.volClientLst = volClientLst;
	}

    public Volume(String volCluster, String volId, String volName, String volPolicy, List<String> volClientLst) {
        this.volCluster = volCluster;
        this.volId = volId;
        this.volName = volName;
        this.volPolicy = volPolicy;
        this.volClientLst = volClientLst;
    } 
    
}
