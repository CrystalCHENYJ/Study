package com.crystal.Repository;

import java.util.*;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Repository;

import com.crystal.Entity.Cluster;
import com.crystal.Entity.Volume;

@Repository
public class SimulationSTGDBDAO {

	private ArrayList<Cluster> clusterTable = new ArrayList<>();
	private ArrayList<Volume> volumeTable = new ArrayList<>();
	
	@PostConstruct
	private void initClusterTable() {
		clusterTable.add(new Cluster("f12p7tcnat01", "NetApp", "Y"));
		clusterTable.add(new Cluster("f12p7tcnat02", "NetApp", "Y"));
		clusterTable.add(new Cluster("n8atcnat01", "NetApp", "Y"));
	}
	
	@PostConstruct
	private void initVolumeTable() {
		volumeTable.add(new Volume("f12p7tcnat01", "aaa-bbb-ccc-111", "Vol01", "Vol01Pol", Arrays.asList("t12gw111", "t12gw222")));
		volumeTable.add(new Volume("f12p7tcnat01", "aaa-bbb-ccc-222", "Vol02", "Vol02Pol", Arrays.asList("t12gw333", "t12gw444")));
		volumeTable.add(new Volume("f12p7tcnat02", "aaa-bbb-ccc-333", "Vol03", "Vol03Pol", Arrays.asList("t12gl123", "t12gw444")));
		volumeTable.add(new Volume("n8atcnat01", "aaa-bbb-ccc-444", "Vol04ˋ", "Vol04Pol", Arrays.asList("t12gl123", "t12gw444")));
		volumeTable.add(new Volume("n8atcnat01", "aaa-bbb-ccc-555", "Vol053", "Vol053Pol", Arrays.asList("t12gl123", "t12gw444")));
	}
}
