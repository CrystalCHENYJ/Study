package com.crystal.Controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.*;


@RestController
public class StorageController implements StorageInterface {
	
	@Override
	public ReplyCientListDto updClients(@RequestBody StorageVolumeUpdClientsDto updClientData) {
		ReplyCientListDto r = new ReplyCientListDto();
		r.setReplycluster(updClientData.getCluster());
		r.setReplyvolId(updClientData.getVolId());
		r.setReplyclientList(updClientData.getClientList());
		return r;
	}

	//To Be Deleted
	@Override
	public ReplyCientListDto1 replyClients(@RequestBody StorageVolumeUpdClientsDto updClientData) {
		ReplyCientListDto1 r = new ReplyCientListDto1();
		r.replycluster = updClientData.getCluster();
		r.replyvolId = updClientData.getVolId();
		r.replyclientList = updClientData.getClientList();
		return r;
	}

	//To Be Deleted	
	@Override
	public String ping() {
		return("Pong");
	}
}

class StorageVolumeUpdClientsDto {

	String cluster = "";
	String volId = "";
	List<String> clientList = null;
	
	public String getCluster() {
		return cluster;
	}
	
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	
	public String getVolId() {
		return volId;
	}
	
	public void setVolId(String volId) {
		this.volId = volId;
	}
	
	public List<String> getClientList() {
		return clientList;
	}
	
	public void setClientList(List<String> clientList) {
		this.clientList = clientList;
	}
}

class ReplyCientListDto {
	
	String replycluster = "";
	String replyvolId = "";
	List<String> replyclientList = null;
	
	public String getReplycluster() {
		return replycluster;
	}
	
	public void setReplycluster(String replycluster) {
		this.replycluster = replycluster;
	}
	
	public String getReplyvolId() {
		return replyvolId;
	}
	
	public void setReplyvolId(String replyvolId) {
		this.replyvolId = replyvolId;
	}
	
	public List<String> getReplyclientList() {
		return replyclientList;
	}
	
	public void setReplyclientList(List<String> replyclientList) {
		this.replyclientList = replyclientList;
	}
}

//To Be Deleted
class ReplyCientListDto1 {
	
	String replycluster = "";
	String replyvolId = "";
	List<String> replyclientList = null;
	
	public String getReplycluster() {
		return replycluster;
	}
	
	public void setReplycluster(String replycluster) {
		this.replycluster = replycluster;
	}
	
	public String getReplyvolId() {
		return replyvolId;
	}
	
	public void setReplyvolId(String replyvolId) {
		this.replyvolId = replyvolId;
	}
	
	public List<String> getReplyclientList() {
		return replyclientList;
	}
	
	public void setReplyclientList(List<String> replyclientList) {
		this.replyclientList = replyclientList;
	}
}