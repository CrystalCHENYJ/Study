package com.crystal.Entity;

public class Cluster {

	private String clusterName;
    private String brand;
    private String isEnabled;
   
	public String getClusterName() {
		return clusterName;
	}

	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getIsEnabled() {
		return isEnabled;
	}

	public void setIsEnabled(String isEnabled) {
		this.isEnabled = isEnabled;
	}

    public Cluster(String clusterName, String brand, String isEnabled) {
        this.clusterName = clusterName;
        this.brand = brand;
        this.isEnabled = isEnabled;
    }
}
