package com.crystal.service;

import java.util.*;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.crystal.Repository.SimulationSTGDBDAO;
import com.crystal.Entity.Volume;

@Service
public class StorageService {
	
	@Autowired
	private SimulationSTGDBDAO storageDAO;

	public Volume getVolume(String volCluster, String volId) {
	    return storageDAO.find(volId)
	            .orElseThrow(() -> new NotFoundException("Can't find Volume."));
	}
	
	public Volume updClients(String volCluster, String volId, List<String> volClientLst) {
		
		Volume vol = getVolume()
		
		
		return null;
	}
	
}
